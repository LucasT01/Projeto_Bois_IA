import streamlit as st
import ai_edge_litert.interpreter as litert
import numpy as np
import cv2
from PIL import Image
import sqlite3
from datetime import datetime
import pandas as pd
import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ==========================================
# CONFIGURAÇÃO DE CAMINHOS
# ==========================================
BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
DB_PATH      = os.path.join(BASE_DIR, 'monitoramento_bois.db')
IMG_SAVE_PATH= os.path.join(BASE_DIR, 'fotos_pesagens')
MODEL_PATH   = os.path.join(BASE_DIR, '..', 'models', 'model.tflite')

os.makedirs(IMG_SAVE_PATH, exist_ok=True)

# ==========================================
# PARÂMETROS DO NEGÓCIO (ajuste se necessário)
# ==========================================
PESO_MINIMO_ABATE = 450   # kg — abaixo disso: NÃO apto
PESO_IDEAL_ABATE  = 520   # kg — acima disso: APTO ideal
# Entre 450 e 520 kg: zona de atenção

# ==========================================
# BANCO DE DADOS (SQLite3)
# ==========================================
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS pesagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            brinco_id TEXT,
            data TEXT,
            peso_estimado REAL,
            caminho_foto TEXT,
            confianca REAL,
            erro REAL,
            status_abate TEXT
        )
    ''')
    # Migração segura: adiciona coluna se não existir (compatibilidade com banco antigo)
    try:
        c.execute("ALTER TABLE pesagens ADD COLUMN status_abate TEXT")
    except Exception:
        pass
    conn.commit()
    conn.close()

# ==========================================
# CARREGAMENTO DO MODELO
# ==========================================
@st.cache_resource
def load_model():
    try:
        interpreter = litert.Interpreter(model_path=MODEL_PATH)
        interpreter.allocate_tensors()
        return interpreter
    except Exception as e:
        st.error(f"Erro ao carregar model.tflite em {MODEL_PATH}: {e}")
        return None

# ==========================================
# PROCESSAMENTO DIGITAL DE IMAGENS (PDI)
# ==========================================
def aplicar_clahe(img_rgb: np.ndarray) -> np.ndarray:
    """Equalização adaptativa de histograma no canal L (espaço LAB).
    Normaliza variações de iluminação entre fotos de campo."""
    lab = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2LAB)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)

def preprocess_image(img: Image.Image) -> np.ndarray:
    """Pré-processamento completo: CLAHE → resize 128x128 → normalização."""
    img_np = np.array(img.convert("RGB"))
    img_np = cv2.resize(img_np, (128, 128))
    img_np = aplicar_clahe(img_np)              # ← CLAHE reintegrado
    return img_np.astype(np.float32) / 255.0

# ==========================================
# INFERÊNCIA COM CONFIANÇA ESTOCÁSTICA
# ==========================================
def predict_with_confidence(interpreter, img: np.ndarray, n: int = 12):
    """Inferência múltipla com ruído gaussiano para estimar incerteza."""
    input_details  = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    preds = []

    for _ in range(n):
        noise    = np.random.normal(0, 0.008, img.shape)
        img_noisy= np.clip(img + noise, 0, 1).astype(np.float32)
        inp      = np.expand_dims(img_noisy, axis=0)

        interpreter.set_tensor(input_details[0]['index'], inp)
        interpreter.invoke()
        pred = interpreter.get_tensor(output_details[0]['index'])[0][0]
        preds.append(pred)

    mean = np.mean(preds)
    std  = np.std(preds)
    coef_var   = std / abs(mean) if mean != 0 else 0
    confidence = float(np.clip(np.exp(-coef_var * 5) * 100, 0, 100))
    erro       = float(std * 2)

    return float(mean), confidence, erro

# ==========================================
# STATUS DE ABATE
# ==========================================
def classificar_abate(peso_kg: float) -> tuple[str, str, str]:
    """Retorna (label, emoji, cor_hex) baseado no peso."""
    if peso_kg >= PESO_IDEAL_ABATE:
        return "APTO PARA ABATE", "✅", "#1a7a3e"
    elif peso_kg >= PESO_MINIMO_ABATE:
        return "ATENÇÃO — Próximo do ponto", "⚠️", "#c47d00"
    else:
        return "NÃO APTO — Continuar engorda", "❌", "#a32d2d"

# ==========================================
# GRÁFICO DE MEDIDOR (GAUGE)
# ==========================================
def plot_gauge(peso: float) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(4, 2.2), subplot_kw={'aspect': 'equal'})
    fig.patch.set_facecolor('none')
    ax.set_facecolor('none')

    # Arcos do gauge
    theta_total = 180
    def arco(ax, inicio, fim, cor, lw=18):
        thetas = np.linspace(np.radians(inicio), np.radians(fim), 100)
        ax.plot(np.cos(thetas), np.sin(thetas), color=cor, lw=lw, solid_capstyle='butt')

    arco(ax, 0,   60,  '#a32d2d')   # vermelho: < 450 kg
    arco(ax, 60,  110, '#c47d00')   # amarelo: 450–520 kg
    arco(ax, 110, 180, '#1a7a3e')   # verde: > 520 kg

    # Agulha
    p_min, p_max = 350, 650
    angulo = 180 - ((peso - p_min) / (p_max - p_min)) * 180
    angulo = np.clip(angulo, 2, 178)
    rad = np.radians(angulo)
    ax.annotate("", xy=(0.75 * np.cos(rad), 0.75 * np.sin(rad)),
                xytext=(0, 0),
                arrowprops=dict(arrowstyle="-|>", color="white", lw=2))
    ax.plot(0, 0, 'o', color='white', markersize=8, zorder=5)

    # Texto central
    ax.text(0, -0.25, f"{peso:.0f} kg", ha='center', va='center',
            fontsize=14, fontweight='bold', color='white')

    ax.set_xlim(-1.2, 1.2)
    ax.set_ylim(-0.4, 1.2)
    ax.axis('off')
    return fig

# ==========================================
# INTERFACE PRINCIPAL
# ==========================================
st.set_page_config(
    page_title="Rayvora Vision Pro v3",
    page_icon="🐂",
    layout="wide"
)
init_db()

# Header
st.markdown("""
<div style='background:linear-gradient(90deg,#1a4a2e,#2d7a4e);
            padding:18px 24px;border-radius:10px;margin-bottom:16px'>
  <h2 style='color:white;margin:0'>🐂 Rayvora Vision Pro — v3.0</h2>
  <p style='color:#b8e4c9;margin:4px 0 0'>
    Sistema Inteligente de Estimativa de Peso Bovino · UFSC Araranguá
  </p>
</div>
""", unsafe_allow_html=True)

menu = ["Nova Pesagem", "Histórico Bruto", "Análise de Evolução", "ℹ️ Sobre o Sistema"]
escolha = st.sidebar.selectbox("Navegação", menu)

# Referência do modelo na sidebar
with st.sidebar:
    st.markdown("---")
    st.markdown("**Parâmetros de Abate**")
    st.markdown(f"🟢 Apto: ≥ **{PESO_IDEAL_ABATE} kg**")
    st.markdown(f"🟡 Atenção: {PESO_MINIMO_ABATE}–{PESO_IDEAL_ABATE} kg")
    st.markdown(f"🔴 Não apto: < **{PESO_MINIMO_ABATE} kg**")

# ─────────────────────────────────────────
# ABA 1 — NOVA PESAGEM
# ─────────────────────────────────────────
if escolha == "Nova Pesagem":
    st.subheader("⚖️ Nova Avaliação de Animal")

    col1, col2 = st.columns([1, 1])

    with col1:
        brinco = st.text_input("Identificação do Brinco (ID único)", "BOI_")
        foto   = st.file_uploader(
            "Carregar foto do Bovino (vista traseira / garupa)",
            type=["jpg", "jpeg", "png"]
        )
        st.caption("📷 Posicione a câmera na altura da garupa, ~2 metros de distância.")

    if foto:
        img = Image.open(foto).convert("RGB")
        with col2:
            st.image(img, use_column_width=True, caption="Imagem carregada para análise")

        if st.button("🚀 Calcular Peso e Avaliar Abate", type="primary"):
            with st.spinner("Processando imagem com CLAHE + inferência LiteRT..."):
                interpreter = load_model()

                if interpreter is not None:
                    processed = preprocess_image(img)
                    peso, conf, erro = predict_with_confidence(interpreter, processed)
                    label, emoji, cor = classificar_abate(peso)

                    # Salvar foto
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    nome_img  = f"{brinco}_{timestamp}.jpg"
                    img.save(os.path.join(IMG_SAVE_PATH, nome_img))

                    # Gravar banco
                    conn = sqlite3.connect(DB_PATH)
                    c = conn.cursor()
                    c.execute("""
                        INSERT INTO pesagens
                          (brinco_id, data, peso_estimado, confianca, erro, caminho_foto, status_abate)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (brinco,
                          datetime.now().strftime("%Y-%m-%d %H:%M"),
                          peso, conf, erro, nome_img, label))
                    conn.commit()
                    conn.close()

                    st.success("Avaliação concluída e registrada!")
                    st.markdown("---")

                    # Banner de status de abate
                    st.markdown(f"""
                    <div style='background:{cor};padding:16px 20px;border-radius:10px;
                                text-align:center;margin-bottom:16px'>
                      <h2 style='color:white;margin:0'>{emoji} {label}</h2>
                    </div>
                    """, unsafe_allow_html=True)

                    # Métricas
                    c1, c2, c3 = st.columns(3)
                    c1.metric("Peso Estimado",       f"{peso:.1f} kg")
                    c2.metric("Confiança do Sistema", f"{conf:.1f}%")
                    c3.metric("Margem de Erro",       f"±{erro:.1f} kg")

                    # Gauge
                    st.markdown("#### Posição na escala de abate")
                    fig = plot_gauge(peso)
                    st.pyplot(fig, use_container_width=False)

                    # Orientação
                    st.markdown("---")
                    if peso >= PESO_IDEAL_ABATE:
                        st.info(f"**Recomendação:** Animal com {peso:.0f} kg — acima do ponto ideal de abate ({PESO_IDEAL_ABATE} kg). Indicado para encaminhamento ao frigorífico.")
                    elif peso >= PESO_MINIMO_ABATE:
                        falta = PESO_IDEAL_ABATE - peso
                        st.warning(f"**Recomendação:** Animal com {peso:.0f} kg — faltam ~{falta:.0f} kg para atingir o ponto ideal. Reavalie em 20–30 dias.")
                    else:
                        falta = PESO_MINIMO_ABATE - peso
                        st.error(f"**Recomendação:** Animal com {peso:.0f} kg — abaixo do mínimo. Continuar engorda por mais tempo (~{falta/0.9:.0f} dias estimados).")

# ─────────────────────────────────────────
# ABA 2 — HISTÓRICO BRUTO
# ─────────────────────────────────────────
elif escolha == "Histórico Bruto":
    st.subheader("📋 Histórico Geral de Pesagens")

    conn = sqlite3.connect(DB_PATH)
    df   = pd.read_sql_query("SELECT * FROM pesagens ORDER BY id DESC", conn)
    conn.close()

    if not df.empty:
        # Filtro por brinco
        brincos = ["Todos"] + sorted(df['brinco_id'].dropna().unique().tolist())
        filtro  = st.selectbox("Filtrar por animal:", brincos)
        if filtro != "Todos":
            df = df[df['brinco_id'] == filtro]

        st.dataframe(df, use_container_width=True)
        st.caption(f"{len(df)} registros exibidos")

        # Download CSV
        csv = df.to_csv(index=False).encode('utf-8')
        st.download_button("⬇️ Exportar CSV", csv, "historico_pesagens.csv", "text/csv")
    else:
        st.info("Nenhum registro encontrado ainda.")

# ─────────────────────────────────────────
# ABA 3 — ANÁLISE DE EVOLUÇÃO
# ─────────────────────────────────────────
elif escolha == "Análise de Evolução":
    st.subheader("📈 Evolução de Peso por Animal")

    conn     = sqlite3.connect(DB_PATH)
    df_bois  = pd.read_sql_query("SELECT DISTINCT brinco_id FROM pesagens", conn)

    if not df_bois.empty:
        boi_sel = st.selectbox("Selecionar animal:", df_bois['brinco_id'])
        df_hist = pd.read_sql_query(
            "SELECT data, peso_estimado, confianca, status_abate FROM pesagens "
            "WHERE brinco_id = ? ORDER BY data ASC",
            conn, params=(boi_sel,)
        )
        conn.close()

        if len(df_hist) >= 1:
            st.markdown(f"### Animal: **{boi_sel}**")

            c1, c2, c3, c4 = st.columns(4)
            ultimo_status = df_hist['status_abate'].iloc[-1] if 'status_abate' in df_hist.columns else "—"
            c1.metric("Último Peso",    f"{df_hist['peso_estimado'].iloc[-1]:.1f} kg")
            c2.metric("Peso Mínimo",    f"{df_hist['peso_estimado'].min():.1f} kg")
            c3.metric("Peso Máximo",    f"{df_hist['peso_estimado'].max():.1f} kg")
            c4.metric("Último Status",  ultimo_status or "—")

            if len(df_hist) >= 2:
                df_chart = df_hist.set_index('data')[['peso_estimado']]
                st.markdown("#### Curva de Ganho de Peso")

                # Gráfico matplotlib com linhas de referência
                fig2, ax2 = plt.subplots(figsize=(10, 4))
                ax2.plot(df_chart.index, df_chart['peso_estimado'],
                         marker='o', color='#2d7a4e', lw=2, label='Peso estimado')
                ax2.axhline(PESO_MINIMO_ABATE, color='#c47d00', ls='--', lw=1.2,
                            label=f'Mínimo abate ({PESO_MINIMO_ABATE} kg)')
                ax2.axhline(PESO_IDEAL_ABATE,  color='#1a7a3e', ls='--', lw=1.2,
                            label=f'Ideal abate ({PESO_IDEAL_ABATE} kg)')
                ax2.fill_between(df_chart.index,
                                 PESO_MINIMO_ABATE, PESO_IDEAL_ABATE,
                                 alpha=0.08, color='#c47d00', label='Zona de atenção')
                ax2.set_ylabel("Peso (kg)")
                ax2.set_xlabel("Data")
                ax2.legend(fontsize=9)
                ax2.grid(True, alpha=0.3)
                plt.xticks(rotation=30, ha='right')
                plt.tight_layout()
                st.pyplot(fig2, use_container_width=True)

                # Ganho médio diário
                if len(df_hist) >= 2:
                    try:
                        datas = pd.to_datetime(df_hist['data'])
                        dias  = (datas.iloc[-1] - datas.iloc[0]).days
                        ganho = df_hist['peso_estimado'].iloc[-1] - df_hist['peso_estimado'].iloc[0]
                        if dias > 0:
                            st.info(f"📊 Ganho médio diário: **{ganho/dias:.2f} kg/dia** ao longo de {dias} dias")
                    except Exception:
                        pass

                st.dataframe(df_hist, use_container_width=True)
            else:
                st.info("Apenas uma pesagem registrada. Faça mais avaliações para gerar o gráfico de evolução.")
                st.dataframe(df_hist, use_container_width=True)
    else:
        conn.close()
        st.warning("Nenhum dado no banco ainda. Realize a primeira pesagem na aba 'Nova Pesagem'.")

# ─────────────────────────────────────────
# ABA 4 — SOBRE O SISTEMA
# ─────────────────────────────────────────
elif escolha == "ℹ️ Sobre o Sistema":
    st.subheader("ℹ️ Sobre o Rayvora Vision Pro v3")
    st.markdown(f"""
    **Instituição:** UFSC — Campus Araranguá  
    **Desenvolvedor:** Ludivino José da Silva  
    **Contexto:** Startup Rayvora — Pecuária de Precisão  

    ---

    ### Pipeline Técnico
    1. **Captura** — foto da vista traseira (garupa) via smartphone
    2. **CLAHE** — equalização adaptativa de histograma (normaliza iluminação de campo)
    3. **Resize** — padronização para 128×128 px, espaço RGB
    4. **MobileNetV2** — backbone pré-treinado (ImageNet) com fine-tuning nas camadas top
    5. **Inferência estocástica** — 12 passes com ruído gaussiano para estimar incerteza
    6. **Classificação de abate** — regras baseadas em peso mínimo ({PESO_MINIMO_ABATE} kg) e ideal ({PESO_IDEAL_ABATE} kg)

    ### Histórico de Métricas
    | Versão | Arquitetura | MAE Treino | MAE Teste | Dataset |
    |--------|-------------|-----------|-----------|---------|
    | v1 (Edge Impulse) | CNN customizada | 50.37 kg | — | 29 imgs |
    | v2 (Edge Impulse) | CNN + camada extra | 32.87 kg | 72.44 kg | 71 imgs |
    | **v3 (Transfer Learning)** | **MobileNetV2 fine-tuned** | **—** | **< 30 kg (meta)** | **71+aug** |

    ### Roadmap
    - 🔲 Expandir dataset para 300–500 imagens de campo
    - 🔲 Segmentação automática da garupa (ROI com YOLOv8)
    - 🔲 App mobile nativo (Flutter + TFLite)
    - 🔲 Modo offline completo para uso sem internet

    ---
    *Rayvora © 2026 — UFSC Araranguá*
    """)
