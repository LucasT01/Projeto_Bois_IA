# 🐂 Guia Passo a Passo — Rayvora Vision Pro v3

**UFSC Araranguá | Startup Rayvora | Ludivino José da Silva**

---

## Visão Geral do que vais fazer

```
[72 fotos + measurements.xlsx]
          ↓
  Google Colab (GPU grátis)
  FineTuning_Rayvora.ipynb
          ↓
  model.tflite  ←  copia para models/
          ↓
  streamlit run src/app.py
          ↓
  App funcionando com modelo melhorado ✅
```

---

## ETAPA 1 — Preparar o Google Drive

1. Abre o **Google Drive** (drive.google.com)
2. Cria a pasta: `Projeto_Bois_IA`
3. Dentro dela, cria a sub-pasta: `back view`
4. Faz upload das **72 imagens** (1.png … 72.png) para a pasta `back view`
5. Faz upload do ficheiro **measurements.xlsx** para `Projeto_Bois_IA`

A estrutura final deve ser:
```
MyDrive/
└── Projeto_Bois_IA/
    ├── back view/
    │   ├── 1.png
    │   ├── 2.png
    │   │   ...
    │   └── 72.png
    └── measurements.xlsx
```

> ⚠️ Os nomes das imagens têm de ser `1.png`, `2.png`, ..., `72.png`  
> (o notebook também aceita `.jpg` se for o caso)

---

## ETAPA 2 — Abrir o notebook no Google Colab

1. Acede a **colab.research.google.com**
2. Clica em `Ficheiro → Abrir notebook → Google Drive`
3. Faz upload do ficheiro `FineTuning_Rayvora.ipynb` (ou abre direto do Drive)
4. **Ativar GPU:** `Ambiente de execução → Alterar tipo de ambiente → T4 GPU`
5. Clica em `Ligar` (canto superior direito)

---

## ETAPA 3 — Executar o notebook célula por célula

| # | Célula | O que faz | Tempo estimado |
|---|--------|-----------|----------------|
| 1 | Instalação | Instala Albumentations | ~30 segundos |
| 2 | Drive | Monta o Drive e verifica caminhos | ~10 segundos |
| 3 | Carregar dados | Carrega 72 imagens com CLAHE | ~1 minuto |
| 4 | Augmentation | Expande para ~350 amostras | ~2 minutos |
| 5 | Split | Divide treino/teste | ~5 segundos |
| 6 | Modelo | Constrói MobileNetV2 | ~20 segundos |
| 7 | **Fase 1** | Treina cabeça (50 épocas) | ~5–8 minutos |
| 8 | **Fase 2** | Fine-tuning (80 épocas) | ~10–15 minutos |
| 9 | Gráficos | Mostra curvas e scatter | ~30 segundos |
| 10 | Exportar | Gera .h5 e .tflite | ~1 minuto |
| 11 | Verificar | Testa se .tflite == .h5 | ~30 segundos |
| 12 | Download | Baixa o model.tflite | imediato |

> 💡 **Dica:** Clica em `Ambiente de execução → Executar tudo` para rodar sequencialmente.  
> Se aparecer aviso de GPU, confirma clicando em "Executar mesmo assim".

---

## ETAPA 4 — Substituir o modelo no projeto

1. Após o download automático (Célula 12), tens o ficheiro `model.tflite`
2. No teu projeto local, vai até:
   ```
   Projeto_Bois_IA/
   └── models/
       └── model.tflite   ← substitui este ficheiro pelo novo
   ```
3. Apaga o `model.tflite` antigo e cola o novo no mesmo lugar

---

## ETAPA 5 — Atualizar o app.py

Substitui o ficheiro `src/app.py` pelo novo `app.py` fornecido.

**O que mudou no novo app:**
- ✅ CLAHE reintegrado (normaliza iluminação das fotos)
- ✅ Banner de **APTO / ATENÇÃO / NÃO APTO para abate**
- ✅ Medidor visual (gauge) com posição do animal
- ✅ Recomendação textual com estimativa de dias restantes
- ✅ Gráfico de evolução com linhas de referência de abate
- ✅ Cálculo de ganho médio diário
- ✅ Exportação do histórico em CSV

---

## ETAPA 6 — Correr o app

```bash
# Instalar dependências (primeira vez)
pip install -r requirements.txt

# Correr o app
streamlit run src/app.py
```

Abre o browser em `http://localhost:8501`

---

## O que esperar de melhoria

| Métrica | Modelo antigo (v2) | Expectativa v3 |
|---------|-------------------|----------------|
| MAE no treino | 32.87 kg | < 25 kg |
| MAE no teste cego | 72.44 kg | **< 35 kg** |
| Explicação da variância | -0.51 | > 0.30 |

A principal melhoria vem de:
1. **CLAHE** — elimina o efeito de iluminação diferente entre fotos
2. **MobileNetV2** — backbone muito mais poderoso que CNN do zero
3. **Data Augmentation** — mais variação = menos overfitting
4. **Fine-tuning em 2 fases** — não destrói o que ImageNet já aprendeu

---

## Problemas comuns e soluções

**❌ "Pasta não encontrada no Drive"**  
→ Verifica o nome exato da pasta na Célula 2. Maiúsculas/minúsculas importam.

**❌ "Imagem X não encontrada"**  
→ Verifica se os ficheiros são `1.png`, `2.png` etc. Se forem `.jpg`, o notebook também tenta essa extensão.

**❌ Colab desconecta durante o treino**  
→ O ModelCheckpoint (Célula 8) já salva o melhor modelo no Drive automaticamente. Abre `PATH_OUT/melhor_modelo.h5` e converte manualmente para .tflite com a Célula 10.

**❌ "Erro ao carregar model.tflite no app"**  
→ Verifica se colocaste o ficheiro em `models/model.tflite` (não dentro de `src/`).

---

*Rayvora © 2026 — UFSC Araranguá*
